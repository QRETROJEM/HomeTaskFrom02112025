document.addEventListener('DOMContentLoaded', () => {
    const cultistLink = document.getElementById('cultist-link');
    const symbolLink = document.getElementById('symbol-link');
    const allTextElements = document.querySelectorAll('.flicker-text');

    const hoverSound = document.getElementById('hoverSound');
    const clickSound = document.getElementById('clickSound');

    // --- Анимация мерцания текста (Улучшено) ---
    // Активируем мерцание после завершения анимации появления (fadeIn)
    const activateFlicker = (element, delay) => {
        setTimeout(() => {
            element.classList.add('active-flicker');
        }, delay);
    };

    allTextElements.forEach((el) => {
        const initialFadeInDelay = parseFloat(getComputedStyle(el).animationDelay) * 1000 || 0;
        const activationDelay = initialFadeInDelay + 2000; // Начинаем мерцание через 2 секунды после завершения fadeIn
        activateFlicker(el, activationDelay);
    });

    // --- Звуковые эффекты ---
    const playSound = (audioElement) => {
        audioElement.currentTime = 0; // Перематываем в начало для повторного воспроизведения
        audioElement.play().catch(e => console.error("Ошибка воспроизведения аудио:", e)); // Обработка возможных ошибок
    };

    cultistLink.addEventListener('mouseover', () => playSound(hoverSound));
    cultistLink.addEventListener('click', () => playSound(clickSound));
    symbolLink.addEventListener('mouseover', () => playSound(hoverSound));
    symbolLink.addEventListener('click', () => playSound(clickSound));

    // --- Эффект параллакса ---
    const parallaxBg = document.getElementById('parallax-bg');
    const movementStrength = 0.03; // Интенсивность движения фона (чем больше, тем сильнее движется)

    document.addEventListener('mousemove', (e) => {
        const mouseX = e.clientX;
        const mouseY = e.clientY;

        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;

        // Вычисляем смещение от центра экрана
        // Нормализуем координаты мыши от -0.5 до 0.5
        const normalizedX = (mouseX / windowWidth) - 0.5;
        const normalizedY = (mouseY / windowHeight) - 0.5;

        // Применяем смещение
        const offsetX = normalizedX * 100 * movementStrength; // Умножаем на 100 для большего диапазона движения
        const offsetY = normalizedY * 100 * movementStrength;

        // Применяем трансформацию для элемента фона
        parallaxBg.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
    });

    // --- Динамическая интенсивность свечения (реагирует на мышь) ---
    const imageLinks = document.querySelectorAll('.image-link');
    const maxGlowOpacity = 0.8; // Максимальная прозрачность свечения
    const minGlowOpacity = 0.15; // Минимальная прозрачность свечения, когда курсор далеко
    const glowActiveRadius = 250; // Радиус в пикселях, в котором свечение активно реагирует на мышь

    document.addEventListener('mousemove', (e) => {
        imageLinks.forEach(link => {
            const glowElement = link.querySelector('.glow');
            const linkRect = link.getBoundingClientRect();
            const linkCenterX = linkRect.left + linkRect.width / 2;
            const linkCenterY = linkRect.top + linkRect.height / 2;

            // Расстояние от курсора до центра изображения
            const distanceX = e.clientX - linkCenterX;
            const distanceY = e.clientY - linkCenterY;
            const distance = Math.sqrt(distanceX * distanceX + distanceY * distanceY);

            let currentOpacity;
            let currentScale;

            if (distance < glowActiveRadius) {
                // Если курсор внутри активного радиуса, рассчитываем интенсивность
                // Интерполируем opacity от max до min по мере удаления от центра
                currentOpacity = maxGlowOpacity - (distance / glowActiveRadius) * (maxGlowOpacity - minGlowOpacity);
                // Интерполируем scale от 1.1 до 0.8 по мере удаления
                currentScale = 1.1 - (distance / glowActiveRadius) * 0.3;
            } else {
                // Если курсор далеко, устанавливаем минимальную интенсивность
                currentOpacity = minGlowOpacity;
                currentScale = 0.8;
            }

            // Применяем рассчитанные значения к элементу свечения
            glowElement.style.opacity = currentOpacity;
            glowElement.style.transform = `translate(-50%, -50%) scale(${currentScale})`;
        });
    });

    // Инициализируем состояние свечения при загрузке страницы
    // (курсор еще не двигался, поэтому устанавливаем минимальное свечение)
    imageLinks.forEach(link => {
        const glowElement = link.querySelector('.glow');
        glowElement.style.opacity = minGlowOpacity;
        glowElement.style.transform = `translate(-50%, -50%) scale(0.8)`;
    });
});